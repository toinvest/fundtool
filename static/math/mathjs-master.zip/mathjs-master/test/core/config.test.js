var assert = require('assert');
var math = require('../../index');

describe('config', function() {
  // TODO: test function config
});