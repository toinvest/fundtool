// TODO: test isCollection.js

