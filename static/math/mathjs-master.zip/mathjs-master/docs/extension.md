# Extension

This page has been moved [here](core/extension.md).
