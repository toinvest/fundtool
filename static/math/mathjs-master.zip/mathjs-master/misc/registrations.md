math.js is registered at the following places:

# package managers
- npm.js: mathjs (npm publish)
- bower:  mathjs (automatically updates via github)
- jam.js: mathjs (jam publish)

# websites
- http://jster.net (automatically updates via github)
- http://www.jsdb.io
- http://jswiki.org
- http://jspkg.com (manually import a project from github)
- http://cdnjs.com (add a project via a git pull-request)

# other
- travis-ci (automatically updates via github)
